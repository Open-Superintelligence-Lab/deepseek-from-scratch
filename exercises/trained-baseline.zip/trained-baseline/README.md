# Experiment 02: a trainable tiny causal language-model baseline

`r01/train.py` trains a 2-layer, 48-dimensional, four-head causal Transformer on CPU. It is an intentionally small educational language-modeling experiment, not a DeepSeek reproduction and not evidence of natural-language generalization.

The corpus is generated locally from an original compositional command grammar. Each full sentence is deterministically assigned to either training or validation with `split_seed`; the two lists have no exact overlap. `r01/dataset.json` records the grammar provenance, vocabulary, dataset/split seeds, and both split lists.

Run with pinned CPU PyTorch (the completed default run lives in `r01`):

```bash
uv run --with 'torch==2.8.0' python r01/train.py --out r02
```

For a learner rerun, change only `training_seed` in `config.json`; hold `dataset_seed` and `split_seed` fixed so the generated corpus and exact held-out validation sentences do not move. Each completed run saves its effective `config.json` snapshot. A populated output directory is rejected so results and checkpoints are not silently overwritten.

The result uses true token-weighted mean next-token cross-entropy. Padding targets are ignored. It reports uniform `log(vocab_size)`, a Laplace-smoothed unigram baseline fit only on training targets, untrained validation loss, trained validation loss, and train/validation checkpoints every 100 steps. It also saves a checkpoint, loss CSV/SVG, a fixed-prompt greedy before/after sample, and a causal-mask invariance test: changing a future input must leave all earlier-position logits exactly unchanged.
